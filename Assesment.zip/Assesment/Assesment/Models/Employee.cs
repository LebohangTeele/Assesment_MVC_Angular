﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assesment.Models
{
    public class Employee
    {
        public string Id { get; set; }
        public string Firstname { get; set; }
        public string SurName { get; set; }
        public string IdType { get; set; }
        public string DOB { get; set; }
    }
}