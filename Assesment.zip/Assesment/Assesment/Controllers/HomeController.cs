﻿using Assesment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace Assesment.Controllers
{
    public class HomeController : Controller
    {
        Test_DBEntities db = new Test_DBEntities();
        public JsonResult Get_AllEmployee()
        {
            using (Test_DBEntities Obj = new Test_DBEntities())
            {
                List<EmployeeInfo> Emp = Obj.EmployeeInfoes.ToList();
                return Json(Emp, JsonRequestBehavior.AllowGet);
            }
        }
      
        public JsonResult Get_EmployeeById(string Id)
        {
            Test_DBEntities db = new Test_DBEntities();
            var EmployeeList = from p in db.EmployeeInfoes.ToList()
                               where p.Id == Id
                               select new Employee() { Id = p.Id, Firstname = p.FirstName, SurName = p.SurName, DOB = p.DOB, IdType = p.IdType };


            return Json(EmployeeList, JsonRequestBehavior.AllowGet);
        }
       
        public string Update_Employee(List<Employee> Emp)
        {
            if (Emp != null)
            {
                using (Test_DBEntities Obj = new Test_DBEntities())
                {
                   // var Emp_ = Obj.Entry(Emp);
                    foreach(var item in Emp)
                    {
                        var EditEmployee = db.EmployeeInfoes.FirstOrDefault(r => r.Id == item.Id);
                        if (EditEmployee != null)
                        {
                            EditEmployee.FirstName = item.Firstname;
                            EditEmployee.SurName = item.SurName;
                            EditEmployee.DOB = item.DOB;
                            EditEmployee.IdType = item.IdType;
                            db.SaveChanges();
                            return "Employee Updated Successfully";

                        }
                    }
                 
                }
            }
            else
            {
                return "Employee Not Updated! Try Again";
            }
            return "uh";
        }
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}